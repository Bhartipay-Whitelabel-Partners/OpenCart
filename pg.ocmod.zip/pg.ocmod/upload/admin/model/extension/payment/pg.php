<?php
class ModelExtensionPaymentPg extends Model {

	public function install() {
		$this->db->query("
			CREATE TABLE IF NOT EXISTS `" . DB_PREFIX . "pg_order_data` (
				`id` int(11) NOT NULL AUTO_INCREMENT,
				`order_id` int(11) NOT NULL,
				`pg_order_id` VARCHAR(255) NOT NULL,
				`transaction_id` VARCHAR(255) NOT NULL,
				`status` ENUM('0', '1')  DEFAULT '0' NOT NULL,
				`pg_response` TEXT,
				`date_added` DATETIME NOT NULL,
				`date_modified` DATETIME NOT NULL,
				PRIMARY KEY (`id`)
			);");
	}

	public function uninstall() {
		$this->db->query("DROP TABLE IF EXISTS `" . DB_PREFIX . "pg_order_data`;");
	}

	public function getPgOrderData($order_id) {

		$query = $this->db->query("SELECT * FROM `" . DB_PREFIX . "pg_order_data` WHERE order_id = '" . (int)$order_id . "' ORDER BY id DESC LIMIT 1");
		if ($query->num_rows) {
			return $query->row;
		} else {
			return false;
		}
	}

	public function saveTxnResponse($data  = array(), $id = false){
		if(empty($data['STATUS'])) return false;

		$status 			= (!empty($data['STATUS']) && $data['STATUS'] =='TXN_SUCCESS') ? 1 : 0;
		$pg_order_id 	= (!empty($data['ORDERID'])? $data['ORDERID']:'');
		$transaction_id 	= (!empty($data['TXNID'])? $data['TXNID']:'');
		if($pg_order_id && $id){
			$sql = "SELECT * from " . DB_PREFIX . "pg_order_data WHERE pg_order_id = '" . $pg_order_id . "'";
			$query = $this->db->query($sql);
			if($query->row){
				$update_response = (array)json_decode($query->row['pg_response']);
				$update_response['STATUS'] 		= $data['STATUS'];
				$update_response['RESPCODE'] 	= $data['RESPCODE'];
				$update_response['RESPMSG'] 	= $data['RESPMSG'];

				$sql =  "UPDATE " . DB_PREFIX . "pg_order_data SET transaction_id = '" . $this->db->escape($transaction_id) . "', status = '" . (int)$status . "', pg_response = '" . $this->db->escape(json_encode($update_response)) . "', date_modified = NOW() WHERE pg_order_id = '" . $pg_order_id . "' AND id = '" . (int)$id . "'";
				$this->db->query($sql);
				return $update_response;
			}			
		}		
		return false;
	}

}